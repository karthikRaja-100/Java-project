package com.example.OnlineBankProcess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBankProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBankProcessApplication.class, args);
	}

}
