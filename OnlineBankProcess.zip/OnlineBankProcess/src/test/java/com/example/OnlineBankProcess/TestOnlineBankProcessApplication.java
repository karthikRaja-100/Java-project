package com.example.OnlineBankProcess;

import org.springframework.boot.SpringApplication;

public class TestOnlineBankProcessApplication {

	public static void main(String[] args) {
		SpringApplication.from(OnlineBankProcessApplication::main).with(TestcontainersConfiguration.class).run(args);
	}

}
